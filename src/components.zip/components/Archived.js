import React from 'react'
// import Cards from './Cards.js'

export default function Archived() {
  return (
    <div>
      <div className="container text-center">
  <div className="row row-cols-4">
    
  </div>
</div>
    </div>

  )
}

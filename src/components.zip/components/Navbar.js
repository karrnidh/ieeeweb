import React from 'react';

export default function Navibar() {
  return (
    <div>
      <nav className="navbar navbar-expand-lg" style={{ backgroundColor: '#ffffff' }}>
        <div className="container-fluid">
          {/* Center section: Navbar buttons */}
          <div className="collapse navbar-collapse d-flex justify-content-center" id="navbarSupportedContent">
            <ul className="navbar-nav mb-2 mb-lg-0 d-flex align-items-center">
              <li className="nav-item">
                <a className="nav-link text-dark-brown" aria-current="page" href="/">Home</a>
              </li>
              <span className="separator mx-2">|</span> {/* Separator */}
              <li className="nav-item">
                <a className="nav-link text-dark-brown" href="/aboutus">About Us</a>
              </li>
              <span className="separator mx-2">|</span> {/* Separator */}
              <li className="nav-item">
                <a className="nav-link text-dark-brown" href="/events">Events</a>
              </li>
              <span className="separator mx-2">|</span> {/* Separator */}
              <li className="nav-item">
                <a className="nav-link text-dark-brown" href="/executivecommittee">Executive Committee</a>
              </li>
              <span className="separator mx-2">|</span> {/* Separator */}
              <li className="nav-item">
                <a className="nav-link text-dark-brown" href="/contactus">Contact Us</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      {/* CSS for dark brown text and spacing */}
      <style>
        {`
          .text-dark-brown {
            color: #3e2a1f !important; /* Dark brown color */
          }
          .separator {
            color: #3e2a1f; /* Match separator color to dark brown */
          }

          /* Mobile-specific changes */
          @media (max-width: 768px) {
            /* Remove separators on mobile */
            .separator {
              display: none;
            }

            /* Create a dropdown for mobile view */
            .navbar-collapse {
              background-color: #ffffff !important;
            }
            .navbar-toggler {
              border: 2px solid #3e2a1f;
              background-color: #3e2a1f;
              color: #fff;
              border-radius: 5px;
              padding: 5px 10px;
            }

            .navbar-toggler-icon {
              display: none;
            }

            /* Display a custom downward arrow for the dropdown button */
            .navbar-toggler span {
              font-size: 18px;
              color: #fff;
              transform: rotate(180deg);
            }

            /* Adjust button layout for mobile */
            .navbar-nav {
              flex-direction: column;
              align-items: flex-start;
            }
            .navbar-nav .nav-item {
              width: 100%;
              text-align: left;
              padding: 10px 15px;
            }
          }
        `}
      </style>
    </div>
  );
}
